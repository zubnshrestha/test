document.getElementById('toggle-menu').addEventListener('click',(e) => {
    document.getElementsByTagName('body')[0].classList.toggle('min-sidebar');
    })